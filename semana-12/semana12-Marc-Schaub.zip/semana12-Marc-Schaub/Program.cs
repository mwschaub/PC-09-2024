﻿using System.ComponentModel.Design;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;

namespace semana_12_MS
{    class Program {
    // Declaración del Método principal
        static void Main()
        {
            
            menu();
        }
        //declaracion del método menú
        static void menu()
        {
            Console.WriteLine("Ingrese dos números: ");
                int a, b;
            while (!int.TryParse(Console.ReadLine(), out a))
            {
                Console.WriteLine("Por favor, ingrese un número válido para a ");
            }
            while (!int.TryParse(Console.ReadLine(), out b))
            {
                Console.WriteLine("Por favor, ingrese un número válido para b ");
            }
            Console.WriteLine("Semana 12: seleccione una opción: ");
            Console.WriteLine("a) sumar");
            Console.WriteLine("b) restar");
            Console.WriteLine("c) multiplicar");

        char opcion = Console.ReadLine().ToLower()[0];
        switch (opcion)
        {
            //opcion a suma , llamada a metodo
                  case 'a':
 
                    Console.WriteLine("El resultado es :" + Suma(a, b));
                    Console.ReadKey();
 
                    break;
                  case 'b':
 
                    Console.WriteLine("El resultado es :" + Resta(a, b));
                    Console.ReadKey();
                  break;
                  case 'c':
 
                    Console.WriteLine("El resultado es :" + Multiplicacion(a, b));
                    Console.ReadKey();
                  break;
                default:
                    Console.WriteLine("La opción seleccionada no es válida.");
                    break;
            }
        }
 
        //envio de parámetros
        public static int Multiplicacion(int a, int b)
        {
            int resultado = 0;
            resultado = a * b;
            return resultado;
        }
        public static int Suma(int a, int b)
        {
            int resultado = 0;
            resultado = a + b;
            return resultado;
        }
        public static int Resta(int a, int b)
        {
            int resultado = 0;
            resultado = a - b;
            return resultado;
        }
    }
}