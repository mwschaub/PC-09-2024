﻿using System.Diagnostics.CodeAnalysis;

namespace codigo1 {
   class codigo1 {
public int[] notas;
 public int suma = 0;
public void datos() {
    notas = new int[8];
for (int i=1; i<notas.Length; i++) {
    Console.WriteLine("Ingrese un número para la nota "+ i + ":");
    notas[i] = Convert.ToInt32(Console.ReadLine());
    
    suma = suma + notas[i];
}
}
public void mostrar(){
     notas = new int[8];
 Console.WriteLine("");
                Console.WriteLine("La suma es: "+suma);
                 Console.ReadKey();

}

public void Promedio()
{
    notas = new int[8];
            Console.WriteLine("");
            double Promedio = suma / notas.Length;
            Console.WriteLine("Promedio es: " + Promedio );
            Console.ReadKey();
}
                static void Main()
        {
            codigo1 arregloUnidimensional_ = new codigo1();
            arregloUnidimensional_.datos();
            arregloUnidimensional_.mostrar();
            arregloUnidimensional_.Promedio();
        }
    }
}
