﻿using System;

namespace codigo2
{
    class ArregloUnidimensional
    {
        //Declaración de arreglo tipo entero sin tamaño especifico
        private string[,] persona;
        private string [] datos = { "el nombre", "el apellido", "la edad", "el numero de telefono" };


        //Metodo cargar
        public void Cargar()
        {
            //Asignando a arreglo un tamaño 5
            persona = new string[4,4];

            //Declaración de iteración For
            for (int i = 0; i < 4; i++)
            {
                Console.Write($"Ingrese {datos[i]} de la persona 1: ");
                String dato;
                dato = Console.ReadLine();
                persona[i,0] = dato;
            }

            Console.WriteLine("");
            for (int n = 0; n < 4; n++)
            {
                Console.Write($"Ingrese {datos[n]} de la persona 2: ");
                String dato2;
                dato2 = Console.ReadLine();
                persona[n, 1] = dato2;
            }

            Console.WriteLine("");
            for (int r = 0; r < 4; r++)
            {
                Console.Write($"Ingrese {datos[r]} de la persona 3: ");
                String dato3;
                dato3 = Console.ReadLine();
                persona[r, 2] = dato3;
            }
            
            Console.WriteLine("");
            for (int l = 0; l < 4; l++)
            {
                Console.Write($"Ingrese {datos[l]} de la persona 4: ");
                String dato4;
                dato4 = Console.ReadLine();
                persona[l, 3] = dato4;
            }
        }
        public void Imprimir()
        {
            Console.WriteLine("");
            Console.WriteLine($"Datos de las personas ingresadas: ");
            //Declaración de iteración For

            Console.WriteLine($"Datos de la persona 1: ");
            for (int i = 0; i < 4; i++)
            {
                Console.WriteLine($"{datos[i]}: {persona[i,0]}");
            }

            Console.WriteLine("");
            Console.WriteLine($"Datos de la persona 2: ");
            for (int n = 0; n < 4; n++)
            {
                Console.WriteLine($"{datos[n]}: {persona[n, 1]}");
            }

            Console.WriteLine("");
            Console.WriteLine($"Datos de la persona 3: ");
            for (int r = 0; r < 4; r++)
            {
                Console.WriteLine($"{datos[r]}: {persona[r, 2]}");
            }

            Console.WriteLine("");
            Console.WriteLine($"Datos de la persona 4: ");
            for (int l = 0; l < 4; l++)
            {
                Console.WriteLine($"{datos[l]}: {persona[l, 3]}");
            }
            Console.ReadKey();
        }
        static void Main()
        {
            ArregloUnidimensional codigo2 = new ArregloUnidimensional();
            codigo2.Cargar();
            codigo2.Imprimir();
        }
    }
}