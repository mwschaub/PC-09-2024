﻿using System.Globalization;

namespace MarcSchaub
{
    class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Ingrese un número entero positivo: ");
            int num = 0;
            num = Convert.ToInt32(Console.ReadLine());
            int resultado = CalcularFactorial(num);
            Console.WriteLine("El factorial de su número es: "+resultado);
    
            int CalcularFactorial(int num)
            {

                if (num == 0)
            {
                return 1;
            }
            else 
            {
                int factorial = 1;
                for (int i = 1; i <= num; i++)
                {
                        factorial *= i;
                }
                return factorial;
            }
            }
         }
     }
 }