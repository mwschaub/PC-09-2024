﻿using System;
using System.Diagnostics.Contracts;

public class Schaub
{
    // propiedades
    int numero;
    string cadena;
    int num1;
    public static void Main()
    {
        Schaub objetoProgram = new Schaub(3, "hola", 4);
        Console.WriteLine("Bienvenido al menu, elija una de las opciones");
        Console.WriteLine("1. Ingreso de valores");
        Console.WriteLine("2. Mostrar valores");
        Console.WriteLine("3. Salir del programa");
int opcion;
string entrada = Console.ReadLine();
        if (!int.TryParse(entrada, out opcion))
        {
            Console.WriteLine("Entrada no válida. Debe ingresar un número entero.");
            return;
        }

        switch (opcion)
        {
            case 1:
                Console.WriteLine("Ingreso de valores");
                        objetoProgram.datos();
                break;
            case 2:
                Console.WriteLine("Mostrar valores");
                        objetoProgram.show();
                break;
            case 3:
                Console.WriteLine("Salir del programa");
                System.Threading.Thread.Sleep(1000);
                break;
            default:
                Console.WriteLine("Opción no válida. Debe ingresar un número entre 1 y 3.");
                break;
        }

    }
 
    Schaub(int numero, string cadena, int num1)
    {
        this.numero = numero;
        this.cadena = cadena;
        this.num1 = num1;
    }
    void show()
    {
        Console.WriteLine(this.numero);
        Console.WriteLine(this.cadena);
        Console.WriteLine(this.num1);   
        Console.ReadKey();
    }
    void datos()
    {
        Console.WriteLine("Ingresa el valor 1");
        int valor1 = Convert.ToInt32(Console.ReadLine());
         Console.WriteLine("Ingresa el valor 2");
        int valor2 = Convert.ToInt32(Console.ReadLine());
          Console.WriteLine("Ingresa el valor 3");
        int valor3 = Convert.ToInt32(Console.ReadLine());
    }
}
