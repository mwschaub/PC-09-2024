﻿using System;
using System.Collections;
namespace marcs {
public class array{

}
public class marcs {
public int[] nums;
 public int suma = 0;
public int promedio = 0;

public void mostrar() {
nums = new int[13];
for (int i=1; i<nums.Length; i++) {
    Console.WriteLine("Ingrese un número para la posición "+ i + ":");
    nums[i] = Convert.ToInt32(Console.ReadLine());
    suma = suma + nums[i];
    promedio = suma / 12;
}
Console.WriteLine("");
Console.WriteLine("La suma es: "+suma);
Console.ReadKey();
}

public void Promedio() {
    nums = new int[12];
for (int i=0; i<nums.Length; i++) {
    Console.WriteLine("Ingrese un número para la posición "+ i + ":");
    nums[i] = Convert.ToInt32(Console.ReadLine());
    suma = suma + nums[i];
    promedio = suma / 12;
}
Console.WriteLine("");
double Promedio = suma / nums.Length;
Console.WriteLine("Promedio es: " + Promedio);
Console.ReadKey();
}
public void maymen() {
    nums = new int[12];
for (int i=0; i<nums.Length; i++) {
    Console.WriteLine("Ingrese un número para la posición "+ i + ":");
    nums[i] = Convert.ToInt32(Console.ReadLine());
}
Array.Sort(nums);
for (int i=0; i<=12; i++) {
Console.WriteLine("La lista de numeros ordenados de menor a mayor es: "+ nums[i]);
}
}
public void menmay() {
    nums = new int[12];
for (int i=0; i<nums.Length; i++) {
    Console.WriteLine("Ingrese un número para la posición "+ i + ":");
    nums[i] = Convert.ToInt32(Console.ReadLine());
}
Array.Sort(nums);
Array.Reverse(nums);
for (int i=0; i<=12; i++) {
Console.WriteLine("La lista de numeros ordenados de mayor a menor es: "+ nums[i]);
}
}
public void tamaño() {
    nums = new int[12];
for (int i=0; i<nums.Length; i++) {
    Console.WriteLine("Ingrese un número para la posición "+ i + ":");
    nums[i] = Convert.ToInt32(Console.ReadLine());
}
    Array.Resize(ref nums, 14);
    Console.WriteLine("Escriba el dato para el nuevo primer valor");
    nums[13] = Convert.ToInt32(Console.ReadLine());
    Console.WriteLine("Escriba el dato para el nuevo segundo valor");
    nums[14] = Convert.ToInt32(Console.ReadLine());
    for (int i=0; i<=14; i++) {
Console.WriteLine("El array re organizado queda: "+ nums[i]);
}
}
public void splitear() {
    nums = new int[12];
for (int i=0; i<nums.Length; i++) {
    Console.WriteLine("Ingrese un número para la posición "+ i + ":");
    nums[i] = Convert.ToInt32(Console.ReadLine());
}
Array.Sort(nums);
string[] stringarray = {string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty, string.Empty};
for (int i = 0; i < nums.Length; i++)
{
    stringarray[i] = nums[i].ToString();
}



string value = "abc123";
char[] valueArray = value.ToCharArray();
Array.Reverse(valueArray);
// string result = new string(valueArray);
string result = String.Join(",", valueArray);
Console.WriteLine(result);

string[] items = result.Split(',');
foreach (string item in items)
{
    Console.WriteLine(item);
}

}
static void Main()
        {
            marcs arraycito = new marcs();
    Console.WriteLine("Bienvenido a menu de numeros, escoja una opción");
    Console.WriteLine("1. mostrar la suma de los números del arreglo");
    Console.WriteLine("2. mostrar el promedio de los números");
    Console.WriteLine("3. Ordenar de menor a mayor y mostrar");
    Console.WriteLine("4. Ordenar de mayor a menor y mostrar");
    Console.WriteLine("5. Cambiar tamaño de arreglo, añadir dos posiciones mas con su respectivo  valor y mostrar.");
    Console.WriteLine("6. Utilizar el operador split");
    int opcion = Convert.ToInt32(Console.ReadLine());
    switch (opcion)
        {
            case 1:
                Console.WriteLine("Seleccionaste la opción 1");
                arraycito.mostrar();
                break;
            case 2:
                Console.WriteLine("Seleccionaste la opción 2");
                arraycito.Promedio();
                break;
            case 3:
                Console.WriteLine("Seleccionaste la opción 3");
                arraycito.maymen();
                break;
            case 4:
                Console.WriteLine("Seleccionaste la opción 4");
                arraycito.menmay();
                break;
            case 5:
                Console.WriteLine("Seleccionaste la opción 5");
                arraycito.tamaño();
                break;
            case 6:
                Console.WriteLine("Seleccionaste la opción 6");
                arraycito.splitear();
                break;
            default:
                Console.WriteLine("Opción no válida");
                break;
        }
        }

}
}
